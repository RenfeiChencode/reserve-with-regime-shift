# Load the library
library(PSPManalysis)

###########################################################
# Bifurcation as a function of WS with and without reserves
###########################################################

DefaultPars <- c(Rho1 = 0.5, Rho2 = 0.5, Delta = 1.0, Eta1 = 0.8, Eta2 = 1.5,    Eta3 = 1.5, 
                 ETSJ = 0.5, ETSA = 0.5, WS    = 0.1, Q    = 1.0, Beta = 2000.0, SR   = 0.2)

# Equilibrium resource values from EBT simulation
init=c(0.1, 0.8635124607, 0.3029066307, 0.2677272558, 1.3866463455)
pars <- DefaultPars
WithReserve <- PSPMequi(modelname = "HarvestWithReserve", biftype = "EQ", startpoint = init, 
                        stepsize = 0.01, parbnds = c(8, 0.05, 0.99), parameters = pars, clean=TRUE, options = c("popEVO", "0"))

# Equilibrium resource values from EBT simulation
init2 <- c(0.1, 0.8795559287, 0.3174891174, 0.5000000000, 1.2556408574)
pars <- DefaultPars
pars["SR"] <- 0.0
NoReserve <- PSPMequi(modelname = "HarvestWithReserve", biftype = "EQ", startpoint = init2, stepsize = 0.01, 
                      parbnds = c(8, 0.05, 0.99), parameters = pars, clean=TRUE, options = c("popEVO", "0"))

################### effect of body size at habitat switch
plot(WithReserve$curvepoints[,1],  rowSums(WithReserve$curvepoints[,9:11]),
     col="red",xlim = c(0, 1.0),ylim = c(0,1.2),type="l",xlab = "",ylab = "Population biomass (scaled unit)") 
points(WithReserve$bifpoints[,1],  rowSums(WithReserve$bifpoints[,9:11]), 
       col="red", pch=8, lwd=1, cex = 1.0)
text(WithReserve$bifpoints[,1],    rowSums(WithReserve$bifpoints[,9:11]),
     WithReserve$biftype, pos=3, offset=0.3, cex = 1.0)

lines(WithReserve$curvepoints[,1], rowSums(WithReserve$curvepoints[,10:11]), col="blue")
points(WithReserve$bifpoints[,1],  rowSums(WithReserve$bifpoints[,10:11]), col="red", pch=8, lwd=1, cex = 1.0)
text(WithReserve$bifpoints[,1],    rowSums(WithReserve$bifpoints[,10:11]), WithReserve$biftype, pos=3, offset=0.3, cex = 1.0)

lines(WithReserve$curvepoints[,1], WithReserve$curvepoints[,11], col="black")
points(WithReserve$bifpoints[,1],  WithReserve$bifpoints[,11], col="red", pch=8, lwd=1, cex = 1.0)
text(WithReserve$bifpoints[,1],    WithReserve$bifpoints[,11], WithReserve$biftype, pos=3, offset=0.3, cex = 1.0)
legend("topleft", c("Total biomass", "Biomass in non-breeding habitat", "Biomass in reserve"), col = c("red", "blue", "black"),
       lty = c(1, 1, 1), lwd = c(1, 1, 1))

plot(NoReserve$curvepoints[,1],  rowSums(NoReserve$curvepoints[,9:11]),
     col="red",xlim = c(0, 1.0),ylim = c(0,1.2),type="l",xlab = "",ylab = "Population biomass (scaled unit)") 
points(NoReserve$bifpoints[,1],  sum(NoReserve$bifpoints[,9:11]), 
       col="red", pch=8, lwd=1, cex = 1.0)
text(NoReserve$bifpoints[,1],    sum(NoReserve$bifpoints[,9:11]),
     NoReserve$biftype, pos=3, offset=0.3, cex = 1.0)

lines(NoReserve$curvepoints[,1], rowSums(NoReserve$curvepoints[,10:11]), col="blue")
points(NoReserve$bifpoints[,1],  sum(NoReserve$bifpoints[,10:11]), col="red", pch=8, lwd=1, cex = 1.0)
text(NoReserve$bifpoints[,1],    sum(NoReserve$bifpoints[,10:11]), NoReserve$biftype, pos=3, offset=0.3, cex = 1.0)

legend("topleft", c("Total biomass", "Biomass in non-breeding habitat"), col = c("red", "blue"),
       lty = c(1, 1), lwd = c(1, 1))

