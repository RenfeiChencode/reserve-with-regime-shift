// - header file -- AMdR - Jan 4, 2022
#define POPULATION_NR             1
#define I_STATE_DIM               2
#define I_CONST_DIM               8
#define ENVIRON_DIM               7
#define OUTPUT_VAR_NR             15
#define PARAMETER_NR              11
#define EVENT_NR                  2
#define TIME_METHOD               DOPRI5
#define DYNAMIC_COHORTS           0


/*===========================================================================*/
